﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using WeatherForecast.Abstraction;

namespace ASP.NETCoreWebApplication.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private readonly ILogger<WeatherForecastController> _logger;
        private readonly IWeatherService weatherService;

        public WeatherForecastController(IWeatherService weatherService, ILogger<WeatherForecastController> logger)
        {
            this.weatherService = weatherService;
            _logger = logger;
        }

        [HttpGet]
        public Task<IEnumerable<IWeatherForecast>> GetWeatherForecast()
        {
            try
            {
                return weatherService.ForecastAsync();
            }
            catch (Exception exception)
            {
                _logger.LogError(exception, $"Failed to process {nameof(GetWeatherForecast)}");
                throw new Exception($"Failed to process {nameof(GetWeatherForecast)}");
            }
        }
    }
}