# Interview Tests



## Test 1
The solution has one Project File names Facilis.LineItems.csproj. This is a simple console application; we have the following need:

	Problem: 
		Write a GENERIC EXTENSION METHOD that will Convert a flat list of items into a Hierarchy.
		Populating Parent and Children Properties of Item class.
		The ItemId, ParentId, Parent and Children properties need to be provided as an input to 
		the Extension Method to make the extensionre-usable for different cases.          
                        
### Assumptions: 
	In the following example, the Root Item always has the ParentId set to 0.



### Expected outcome 
When running the program, we expect to see the following output in the command line.

![Console output](images/Output.jpg)


## Test 2
This is an Asp.net Core application with a React frontend. Navigate to the solution and run the application. The instructions are found on the index page of the web site.